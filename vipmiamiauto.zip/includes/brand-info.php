<?php
   $brandName= 'Premium Paysol';
   $brandNameUp= 'PREMIUM PAYSOL';
   $brandShortCapsName= "";
   $brandTFN= '+6-531 59 2494';
   $brandLocal= '';
   $brandShortLocal= '';
   $brandDomain= 'premiumpaysol.com';
   $brandAddress= '';
   $brandShortName='premiumpaysol';
   $cversion='1.1';
?>

<!-- <?php //echo"$brandName";?> -->