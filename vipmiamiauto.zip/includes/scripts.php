<script type="text/javascript" src="./assets/js/vendors.js"></script>
<script type="text/javascript" src="./assets/js/functions.js"></script>