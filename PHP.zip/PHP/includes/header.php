<style type="text/css">
	.loaderscreen {
		position: fixed;
		z-index: 99999;
		width: 100%;
		height: 100%;
		background-color: #FFF;
		/* background-image: url('/assets/img/icons/ic-loading.gif'); */
		background-position: center;
		background-repeat: no-repeat;
	}
	
	@media (max-width:991px) {
		.loaderscreen {
			background-size: 10%;
		}
	}
</style>
<div class="loaderscreen js-loaderscreen"></div>
<header class="header js-fixed">
	<div class="container">
		<div class="fflex">
			<a href="/" class="logo">
				<img src="/assets/img/brand/logo.svg" alt="" class="js-tosvg">
			</a>
			<div class="navigation">
				<ul>
					<li>
						<a href="/about-us/">About Us</a>
					</li>
					<li>
						<a href="/products/">Products</a>
					</li>
					<li>
						<a href="/platforms/">Platforms</a>
					</li>
					<li>
						<a href="/partners/">Partners</a>
					</li>
					<li>
						<a href="/newsroom/">Newsroom</a>
					</li>
					<li>
						<a href="/contact-us/">Contact Us</a>
					</li>
				</ul>
			</div>
			<div class="nav-hamburger js-menubtn">
				<span></span>
				<span></span>
				<span></span>
				<span></span>
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
	<div class="defaultOverlay js-defaultOverlay"></div>
</header>