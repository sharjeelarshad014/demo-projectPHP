<script type="text/javascript" src="/assets/js/vendors.js?v=<?php echo "$cversion";?>"></script>
<script type="text/javascript" src="/assets/js/functions.js?v=<?php echo "$cversion";?>"></script>