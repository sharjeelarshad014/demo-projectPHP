<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
	<?php include($_SERVER['DOCUMENT_ROOT']."/includes/brand-info.php"); ?>
	<title>Home | <?php echo "$brandName";?></title>
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<?php include($_SERVER['DOCUMENT_ROOT']."/includes/style.php"); ?>
</head>

<body>
	<!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->
	<?php include($_SERVER['DOCUMENT_ROOT']."/includes/header.php"); ?>
	<div class="banner gradient-1">
		<a href="javascript:;" class="ic-mouse" data-scrolltarget="sec-ab">
			<img src="/assets/img/svg/ic-mouse-top.svg" alt="" class="js-tosvg">
			<img src="/assets/img/svg/ic-mouse-bottom.svg" alt="" class="js-tosvg ic-mouse-bottom">
		</a>
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-lg-6 col-xl-5">
					<div class="banner-content">
						<h4></h4>
						<p></p>
						<a href="/about-us/" class="btn btn-primary">About Us</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="stripe-3 sec-about">
		<div class="container">
			<div></div>
		</div>
	</div>

	<div class="stripe-1 bgc-black carousel-sec">
		<div class="container">
		</div>
	</div>
	
	<div class="stripe parallax-sec bg-detail js-parallax" style="background-image: url('/assets/img/bg/bg2.jpg');">
		<div class="overlay"></div>
		<div class="container">
		</div>
	</div>

	<?php include($_SERVER['DOCUMENT_ROOT']."/includes/footer.php"); ?>
	<?php include($_SERVER['DOCUMENT_ROOT']."/includes/scripts.php"); ?>
</body>
</html>