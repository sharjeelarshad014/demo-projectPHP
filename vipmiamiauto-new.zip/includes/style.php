<link rel="icon" type="image/x-icon" size="16x16" href="/favicon.ico">
<link rel="stylesheet" type="text/css" href="./assets/css/style.min.css"/>
<link rel="stylesheet" href="./assets/css/fontawesome/css/fontawesome.min.css">
<!--[if IE]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->